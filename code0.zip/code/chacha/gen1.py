import os
import subprocess
import struct
import re
import time  # 用于测量时间

def quarter_round(x, a, b, c, d):
    x[a] = (x[a] + x[b]) & 0xFFFFFFFF
    x[d] ^= x[a]
    x[d] = ((x[d] << 16) | (x[d] >> 16)) & 0xFFFFFFFF
    x[c] = (x[c] + x[d]) & 0xFFFFFFFF
    x[b] ^= x[c]
    x[b] = ((x[b] << 12) | (x[b] >> 20)) & 0xFFFFFFFF
    x[a] = (x[a] + x[b]) & 0xFFFFFFFF
    x[d] ^= x[a]
    x[d] = ((x[d] << 8) | (x[d] >> 24)) & 0xFFFFFFFF
    x[c] = (x[c] + x[d]) & 0xFFFFFFFF
    x[b] ^= x[c]
    x[b] = ((x[b] << 7) | (x[b] >> 25)) & 0xFFFFFFFF

def chacha20_block(key, counter, machine_code, offset):
    constants = [0x61707865, 0x3320646E, 0x79622D32, 0x6B206574]
    key_state = list(struct.unpack('<8I', key))
    counter_word = [counter & 0xFFFFFFFF]
    machine_code_bytes = bytes.fromhex(machine_code)
    machine_code_part = machine_code_bytes[:8].ljust(8, b'\x00')
    offset_unsigned = offset & 0xFFFFFFFF
    offset_bytes = offset_unsigned.to_bytes(4, byteorder='little')
    nonce_bytes = machine_code_part + offset_bytes
    nonce = list(struct.unpack('<3I', nonce_bytes))
    state = constants + key_state + counter_word + nonce
    working_state = state[:]
    for _ in range(10):
        quarter_round(working_state, 0, 4, 8, 12)
        quarter_round(working_state, 1, 5, 9, 13)
        quarter_round(working_state, 2, 6, 10, 14)
        quarter_round(working_state, 3, 7, 11, 15)
        quarter_round(working_state, 0, 5, 10, 15)
        quarter_round(working_state, 1, 6, 11, 12)
        quarter_round(working_state, 2, 7, 8, 13)
        quarter_round(working_state, 3, 4, 9, 14)
    for i in range(16):
        working_state[i] = (working_state[i] + state[i]) & 0xFFFFFFFF
    return b''.join(struct.pack('<I', word) for word in working_state)

def get_text_section_info(obj_path):
    objdump_command = f"objdump -d {obj_path}"
    result = subprocess.run(objdump_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            universal_newlines=True)
    text_section_pattern = re.compile(r"^\s*(\S+):\s+([0-9a-fA-F]+(?:\s+[0-9a-fA-F]+)*)\s+.*")

    inside_text_section = False
    instructions = []
    text_section_base_addr = None

    for line in result.stdout.splitlines():
        if '.text' in line:
            inside_text_section = True
            continue

        if inside_text_section:
            match = text_section_pattern.match(line)
            if match:
                addr = match.group(1)
                machine_code = match.group(2).replace(" ", "")

                if not text_section_base_addr:
                    text_section_base_addr = addr

                instructions.append((addr, machine_code))

    if not instructions or not text_section_base_addr:
        print("Could not find any instructions in the .text section or base address.")
        return [], None

    return instructions, text_section_base_addr

def generate_tag(instruction_addr, machine_code, key, counter, offset_unsigned):
    instruction_addr = instruction_addr.replace(" ", "").replace("\n", "")
    machine_code = machine_code.replace(" ", "").replace("\n", "")
    instruction_addr = instruction_addr.lstrip("0x")

    if not all(c in "0123456789abcdefABCDEF" for c in instruction_addr):
        print(f"Invalid address (non-hexadecimal): {instruction_addr}")
        return None, None

    if not all(c in "0123456789abcdefABCDEF" for c in machine_code):
        print(f"Invalid machine code (non-hexadecimal): {machine_code}")
        return None, None

    try:
        keystream_block = chacha20_block(key, counter, machine_code, offset_unsigned)
        final_tag = ''.join(f'{byte:02x}' for byte in keystream_block[:8])
        offset_hex = format(offset_unsigned, 'x')
        iv_string = (machine_code + offset_hex).ljust(24, '0')[:24]
        return f"{final_tag}({offset_unsigned})", iv_string
    except ValueError as e:
        print(f"Error generating tag: {e}")
        return None, None

def save_instruction_info(obj_path, output_file="output.txt", tag_file="zhangben.txt", params_file="canshu.txt", time_file="time.txt"):
    instructions, text_section_base_addr = get_text_section_info(obj_path)

    if instructions and text_section_base_addr:
        try:
            text_section_base_addr = int(text_section_base_addr, 16)
        except ValueError as e:
            print(f"Error converting base address to integer: {e}")
            return

        key = os.urandom(32)
        counter = int.from_bytes(os.urandom(4), 'little')

        tags = []
        times = []

        with open(output_file, "w") as f_output, open(params_file, "w") as f_params:
            f_params.write(f"Key: {key.hex()}\n")
            f_params.write(f"Counter: {counter}\n")

            for addr, machine_code in instructions:
                current_offset = int(addr, 16)
                offset = current_offset - text_section_base_addr
                offset_unsigned = offset & 0xFFFFFFFF

                start_time = time.perf_counter()

                tag, iv_string = generate_tag(addr, machine_code, key, counter, offset_unsigned)

                end_time = time.perf_counter()

                if tag and iv_string:
                    f_output.write(f"Offset: {offset_unsigned}\n")
                    f_output.write(f"Machine Code: {machine_code}\n")
                    f_output.write(f"IV (hex): {iv_string}\n")
                    f_output.write('-' * 40 + '\n')
                    tags.append(tag)

                    tag_generation_time = end_time - start_time
                    times.append(tag_generation_time)

        with open(time_file, "w") as f_time:
            for i, t in enumerate(times):
                f_time.write(f"{t:.9f}\n")

        with open(tag_file, "w") as f_tags:
            f_tags.write(" % ".join(tags))

        print(f"Instruction information saved to {output_file}")
        print(f"Tags saved to {tag_file}")
        print(f"Time records saved to {time_file}")
        print(f"Key and Counter saved to {params_file}")
    else:
        print("Failed to retrieve instructions.")

# 示例用法
obj_path = r"/home/tlsend/trivium/add/finance1"  # 替换为你的.o文件路径
save_instruction_info(obj_path)