import os
import gdb
import struct
import re
import time

TAG_BITS = 64     # 标签比特数（支持2/4/5/6/8/16）
DEFAULT_RUNS = 50  # 默认验证次数

# 全局变量用于记录各阶段运行时间
source_time = 0.0
stepi_hex_time = 0.0

def quarter_round(x, a, b, c, d):
    x[a] = (x[a] + x[b]) & 0xFFFFFFFF
    x[d] ^= x[a]
    x[d] = ((x[d] << 16) | (x[d] >> 16)) & 0xFFFFFFFF
    x[c] = (x[c] + x[d]) & 0xFFFFFFFF
    x[b] ^= x[c]
    x[b] = ((x[b] << 12) | (x[b] >> 20)) & 0xFFFFFFFF
    x[a] = (x[a] + x[b]) & 0xFFFFFFFF
    x[d] ^= x[a]
    x[d] = ((x[d] << 8) | (x[d] >> 24)) & 0xFFFFFFFF
    x[c] = (x[c] + x[d]) & 0xFFFFFFFF
    x[b] ^= x[c]
    x[b] = ((x[b] << 7) | (x[b] >> 25)) & 0xFFFFFFFF

def chacha20_block(key, counter, machine_code, offset):
    constants = [0x61707865, 0x3320646E, 0x79622D32, 0x6B206574]
    key_state = list(struct.unpack('<8I', key))
    counter_word = [counter & 0xFFFFFFFF]
    machine_code_bytes = bytes.fromhex(machine_code)
    machine_code_part = machine_code_bytes[:8].ljust(8, b'\x00')
    offset_unsigned = offset & 0xFFFFFFFF
    offset_bytes = offset_unsigned.to_bytes(4, byteorder='little')
    nonce_bytes = machine_code_part + offset_bytes
    nonce = list(struct.unpack('<3I', nonce_bytes))
    state = constants + key_state + counter_word + nonce
    working_state = state[:]
    for _ in range(10):
        quarter_round(working_state, 0, 4, 8, 12)
        quarter_round(working_state, 1, 5, 9, 13)
        quarter_round(working_state, 2, 6, 10, 14)
        quarter_round(working_state, 3, 7, 11, 15)
        quarter_round(working_state, 0, 5, 10, 15)
        quarter_round(working_state, 1, 6, 11, 12)
        quarter_round(working_state, 2, 7, 8, 13)
        quarter_round(working_state, 3, 4, 9, 14)
    for i in range(16):
        working_state[i] = (working_state[i] + state[i]) & 0xFFFFFFFF
    return b''.join(struct.pack('<I', word) for word in working_state)

class Debugger(gdb.Command):
    def __init__(self):
        super(Debugger, self).__init__("stepi_hex", gdb.COMMAND_USER)
        self.text_start = None
        self.text_end = None
        self.compressed_values = {}
        self.compressed_file = os.path.expanduser('/home/tlsend/chacha/add/zhangben.txt')
        self.key = None
        self.counter = None
        self.instruction_cache = {}  # 指令验证缓存
        self.last_pc = None          # 上一条指令的PC
        self.last_instr_length = 0   # 上一条指令的长度
        self.initialize()

    def initialize(self):
        start_time = time.time()
        self.load_canshu()
        self.compressed_values = self.load_zhangben_values()
        if not self.compressed_values:
            print("错误：账本加载失败")
        else:
            print("账本加载成功")
        end_time = time.time()
        global source_time
        source_time = end_time - start_time
        print(f"Source阶段运行时间: {source_time:.6f} 秒 [[2]]")

    def get_text_segment_bounds(self):
        """获取.text段的边界"""
        if self.text_start is None or self.text_end is None:
            try:
                output = gdb.execute("info files", to_string=True)
                for line in output.splitlines():
                    if ".text" in line:
                        parts = line.split()
                        if len(parts) >= 4 and parts[0].startswith('0x') and parts[2].startswith('0x'):
                            self.text_start = int(parts[0], 16)
                            self.text_end = int(parts[2], 16)
                            print(f".text段范围: {self.text_start:#x} - {self.text_end:#x}")
                            break
                if self.text_start is None or self.text_end is None:
                    print("警告: 未找到.text段边界，使用默认值")
                    try:
                        main_info = gdb.execute("info address main", to_string=True)
                        main_addr = int(re.search(r'0x[0-9a-fA-F]+', main_info).group(0), 16)
                        self.text_start = main_addr - 0x1000
                        self.text_end = main_addr + 0x10000
                        print(f"使用估计的.text段范围: {self.text_start:#x} - {self.text_end:#x}")
                    except Exception as e:
                        print(f"获取main地址失败: {e}")
                        self.text_start = 0x555555554000
                        self.text_end = 0x555555564000
                        print(f"使用默认.text段范围: {self.text_start:#x} - {self.text_end:#x}")
            except Exception as e:
                print(f"获取.text段边界失败: {e}")
                self.text_start = 0x555555554000
                self.text_end = 0x555555564000
                print(f"使用默认.text段范围: {self.text_start:#x} - {self.text_end:#x}")
        return self.text_start, self.text_end

    def get_instruction_info(self, address):
        """获取指令信息(机器码、长度和汇编)"""
        try:
            arch = gdb.selected_frame().architecture()
            insn = arch.disassemble(address)[0]
            length = insn['length']
            mem = gdb.selected_inferior().read_memory(address, length).tobytes()
            hex_str = ''.join(f"{b:02x}" for b in mem).ljust(16, '0')[:16]
            return hex_str, length, insn['asm'].strip().lower()
        except gdb.error as e:
            print(f"读取指令失败 @{address:#x}: {e}")
            return "00" * 16, 1, ""

    def get_instruction_length(self, address):
        """获取指令长度"""
        try:
            arch = gdb.selected_frame().architecture()
            insn = arch.disassemble(address)[0]
            return insn['length']
        except gdb.error as e:
            print(f"获取指令长度失败 @{address:#x}: {e}")
            return 1

    def generate_tag(self, keystream_block, offset):
        tag_bytes_length = (TAG_BITS + 7) // 8
        tag_bytes = keystream_block[:tag_bytes_length]
        tag_hex = ''.join(f"{byte:02x}" for byte in tag_bytes)
        if TAG_BITS % 8 != 0:
            start_bit = 8 - (TAG_BITS % 8)
            first_byte = tag_bytes[0] >> start_bit
            for i in range(1, tag_bytes_length):
                first_byte = (first_byte << 8) | tag_bytes[i]
            tag_value = first_byte & ((1 << TAG_BITS) - 1)
            hex_length = (TAG_BITS + 3) // 4
            tag_hex = f"{tag_value:0{hex_length}x}"
        return tag_hex

    def verify_instruction_tag(self, address, context="[验证]"):
        """验证指定地址指令的tag"""
        text_start, text_end = self.get_text_segment_bounds()
        if not text_start:
            return False
        
        # 检查地址是否在.text段内
        if not (text_start <= address < text_end):
            print(f"{context} 跳过非.text段地址: {address:#x} [[1]]")
            return True
        
        offset = address - text_start
        
        # 检查缓存
        if offset in self.instruction_cache:
            return True
        
        machine_code, _, _ = self.get_instruction_info(address)
        
        try:
            keystream_block = chacha20_block(self.key, self.counter, machine_code, offset)
            current_tag = self.generate_tag(keystream_block, offset)
            expected_tag = self.compressed_values.get(offset)
            
            if expected_tag is None:
                print(f"{context} 警告: 偏移量 {offset} 未在账本中找到 [[2]]")
                return False
            elif current_tag == expected_tag:
                print(f"{context} 偏移量: {offset}, 地址: {address:#x}, Tag: {current_tag}, 验证成功 [[1]]")
                self.instruction_cache[offset] = True  # 缓存验证结果
                return True
            else:
                print(f"验证失败！中断程序! {context} 偏移量: {offset}, 地址: {address:#x}, 当前Tag: {current_tag}, 预期Tag: {expected_tag} [[1]]")
                gdb.execute("quit")
                return False
        except Exception as e:
            print(f"生成校验码失败 @{address:#x}: {e}")
            gdb.execute("quit")
            return False

    def load_zhangben_values(self):
        if not os.path.exists(self.compressed_file):
            print(f"账本文件 {self.compressed_file} 不存在")
            return {}
        try:
            values = {}
            hex_length = (TAG_BITS + 3) // 4
            pattern = re.compile(rf'([0-9a-fA-F]{{{hex_length}}})\s*\((\d+)\)')
            with open(self.compressed_file, 'r') as f:
                content = f.read().replace('%', ' ')
                for match in pattern.finditer(content):
                    tag, offset = match.groups()
                    values[int(offset)] = tag.lower()
    
            if values:
                offsets = list(values.keys())
                
            return values
        except Exception as e:
            print(f"加载账本失败: {e}")
            return {}

    def load_canshu(self):
        try:
            with open('canshu.txt', 'r') as f:
                lines = f.readlines()
                for line in lines:
                    if line.startswith('Key:'):
                        self.key = bytes.fromhex(line.strip().split(': ')[1])
                    elif line.startswith('Counter:'):
                        self.counter = int(line.strip().split(': ')[1])
                    elif line.startswith('TAG_BITS:'):
                        global TAG_BITS
                        TAG_BITS = int(line.strip().split(': ')[1])
            if not self.key or not self.counter:
                print("错误：canshu.txt 格式不正确或缺少 Key/Counter")
                return False
            return True
        except Exception as e:
            print(f"加载参数失败: {e}")
            return False

    def detect_control_flow_change(self, current_pc):
        """
        检测是否发生控制流变化
        参考LM算法实现，只基于PC连续性判断
        """
        if self.last_pc is None:
            return False
        
        # 计算预期的下一条指令PC
        expected_next_pc = self.last_pc + self.last_instr_length
        
        # 检查当前PC是否等于预期PC
        return current_pc != expected_next_pc

    def is_program_exiting(self, pc):
        """检查程序是否正在退出"""
        try:
            frame = gdb.selected_frame()
            func = frame.function()
            if func:
                func_name = func.name.lower() if func.name else ""
                exit_functions = [
                    'exit', '_exit', '__run_exit_handlers', '__libc_start_main',
                    '__do_global_dtors_aux', '__call_tls_dtors', 'dtor', 'atexit',
                    '__cxa_finalize', 'fini', '__libc_csu_fini'
                ]
                for exit_func in exit_functions:
                    if exit_func in func_name:
                        return True
            return False
        except Exception as e:
            print(f"检查程序退出状态失败: {e}")
            return False

    def invoke(self, arg, from_tty):
        args = arg.split()
        num_runs = int(args[0]) if args else DEFAULT_RUNS
        total_time = 0.0
        
        for run in range(1, num_runs + 1):
            print(f"\n{'='*30} 第 {run}/{num_runs} 次验证 {'='*30}")
            start_time = time.time()
            
            # 重置状态
            self.text_start = None
            self.text_end = None
            self.compressed_values = self.load_zhangben_values()
            self.instruction_cache = {}
            self.last_pc = None
            self.last_instr_length = 0
            
            try:
                gdb.execute("delete breakpoints")
                gdb.execute("break main")
                gdb.execute("run")
            except gdb.error as e:
                print(f"启动失败: {e}")
                break
            
            while True:
                try:
                    pc = gdb.selected_frame().pc()
                except gdb.error:
                    print("程序终止")
                    break
                
                # 检查程序是否正在退出
                if self.is_program_exiting(pc):
                    print("检测到程序即将退出，停止验证")
                    break
                
                # 检测控制流变化
                is_dynamic = self.detect_control_flow_change(pc)
                
                # 验证当前指令
                context = "[动态验证]" if is_dynamic else "[静态验证]"
                self.verify_instruction_tag(pc, context=context)
                
                # 获取指令信息
                _, instr_length, asm = self.get_instruction_info(pc)
                
                # 保存当前PC和指令长度，用于下一次检测
                self.last_pc = pc
                self.last_instr_length = instr_length
                
                # 单步执行
                try:
                    # 对于PLT调用，使用nexti跳过
                    if '@plt' in asm:
                        print(f"[PLT跳过] 跳过PLT调用: {pc:#x}, {asm}")
                        gdb.execute("ni", to_string=True)
                    else:
                        gdb.execute("si", to_string=True)
                except gdb.error as e:
                    error_str = str(e).lower()
                    if "exited" in error_str or "no function contains program counter" in error_str:
                        print(f"程序已退出: {e}")
                        break
                    elif "signal" in error_str and "sigsegv" in error_str:
                        print("程序发生段错误，终止验证")
                        break
            
            end_time = time.time()
            run_time = end_time - start_time
            total_time += run_time
            print(f"第 {run} 次验证完成，耗时: {run_time:.6f} 秒")
        
        # 记录stepi_hex阶段时间
        global stepi_hex_time
        stepi_hex_time = total_time
        print(f"\n{'='*30} 验证统计 {'='*30}")
        print(f"总验证次数: {num_runs}")
        print(f"Source阶段时间: {source_time:.6f} 秒")
        print(f"Stepi_hex阶段时间: {stepi_hex_time:.6f} 秒")
        print(f"总运行时间: {source_time + stepi_hex_time:.6f} 秒")
        print(f"平均单次时间: {(source_time + stepi_hex_time)/num_runs:.6f} 秒 [[2]]")

Debugger()