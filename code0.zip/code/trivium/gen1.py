import os
import subprocess
import re

def get_text_section_info(obj_path):
    """Get all instructions and their relative offsets in .text section of an ELF .o file."""
    objdump_command = f"objdump -d {obj_path}"
    result = subprocess.run(objdump_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            universal_newlines=True)

    # Define a regular expression to match address and machine code in .text section
    text_section_pattern = re.compile(r"^\s*(\S+):\s+([\da-fA-F\s]+)\s+.*")  # Match address and machine code

    inside_text_section = False
    instructions = []
    text_section_base_addr = None

    for line in result.stdout.splitlines():
        if '.text' in line:
            inside_text_section = True
            continue

        if inside_text_section:
            match = text_section_pattern.match(line)
            if match:
                addr = match.group(1)
                machine_code = match.group(2).replace(" ", "")  # Remove spaces between hex bytes

                # The first address in .text section is the base address
                if not text_section_base_addr:
                    text_section_base_addr = addr

                instructions.append((addr, machine_code))
    
    if not instructions or not text_section_base_addr:
        print("Could not find any instructions in the .text section or base address.")
        return [], None  # Return empty list and None for base address if no instructions are found

    print(f"Text section base address: {text_section_base_addr}")

    return instructions, text_section_base_addr

def trivium_initialization(key, iv):
    """
    Initialize the Trivium state vector with the given key and iv.

    :param key: 80-bit key (10 bytes)
    :param iv: 80-bit IV (10 bytes)
    :return: Initialized state vector
    """
    state = [0] * 288  # Initialize a list of size 288 for the state vector (36 bytes)

    # Convert each byte of the key into its binary representation and fill the state
    for i in range(10):
        key_bits = bin(key[i])[2:].zfill(8)  # Convert the byte to an 8-bit binary string
        for j in range(8):
            state[92 - i * 8 + j] = int(key_bits[j])  # Fill state with key's bits (from 92 to 83)

    # Convert each byte of the iv into its binary representation and fill the state
    for i in range(10):
        iv_bits = bin(iv[i])[2:].zfill(8)  # Convert the byte to an 8-bit binary string
        for j in range(8):
            state[176 - i * 8 + j] = int(iv_bits[j])  # Fill state with iv's bits (from 176 to 167)

    state[177:284] = [0] * (284 - 177 + 1)  # Fill the rest of state with zeros
    state[285:287] = [1, 1, 1]  # Set last 3 positions to [1, 1, 1]

    # Perform 1152 rounds of Trivium algorithm for initialization
    for _ in range(1152):
        t1 = (state[65] ^ (state[90] & state[91]) ^ state[92] ^ state[170])
        t2 = (state[161] ^ (state[174] & state[175]) ^ state[176] ^ state[263])
        t3 = (state[242] ^ (state[285] & state[286]) ^ state[287] ^ state[68])

        # Update the state based on Trivium algorithm
        state[0:92] = [t1] + state[0:91]
        state[93:176] = [t2] + state[93:175]
        state[177:287] = [t3] + state[177:286]
    
    return state

def generate_stream(key, iv, N=64):
    """
    Generate a keystream based on Trivium for N rounds.

    :param key: The 80-bit key for Trivium.
    :param iv: The 80-bit IV for Trivium.
    :param N: The number of rounds to run Trivium (default: 64 for 64-bit keystream).
    :return: The generated keystream.
    """
    state = trivium_initialization(key, iv)  # Initialize state with the provided key and iv
    keystream = []

    for _ in range(N):
        t1 = (state[65] ^ state[92])
        t2 = (state[161] ^ state[176])
        t3 = (state[242] ^ state[287])

        Zi = t1 ^ t2 ^ t3
        keystream.append(str(Zi))  # Ensure Zi is treated as a string ('0' or '1')

        t1 = t1 ^ (state[90] & state[91]) ^ state[170]
        t2 = t2 ^ (state[174] & state[175]) ^ state[263]
        t3 = t3 ^ (state[285] & state[286]) ^ state[68]

        state[0:92] = [t1] + state[0:91]
        state[93:176] = [t2] + state[93:175]
        state[177:287] = [t3] + state[177:286]
    
    # Join the keystream into a single binary string
    keystream_bits = ''.join(keystream)  # This will now be a string of '0's and '1's
    return keystream_bits[:64]  # Ensure the keystream is exactly 64 bits long

def save_instructions_and_tags(obj_path, output_file="output.txt", tag_file="zhangben.txt"):
    instructions, text_section_base_addr = get_text_section_info(obj_path)
    
    # Generate a random 80-bit key (10 bytes)
    key = os.urandom(10)
    
    # Convert the key to hexadecimal format
    key_hex = key.hex()
    
    # Save the key to key.txt
    try:
        with open("key.txt", "w") as key_file:  # 使用 'w' 模式写入文本
            key_file.write(key_hex)
        print(f"Generated 80-bit key (hex) and saved to key.txt: {key_hex}")
    except Exception as e:
        print(f"Error writing key to file: {e}")
        return
    
    counter = 0  # 添加计数器
    
    if instructions and text_section_base_addr:
        # Convert text_section_base_addr to integer
        try:
            text_section_base_addr = int(text_section_base_addr, 16)
        except ValueError as e:
            print(f"Error converting base address to integer: {e}")
            return

        with open(output_file, "w") as f_output, open(tag_file, "w") as f_tags:
            for i, (addr, machine_code) in enumerate(instructions):  # Process all instructions in the text section
                # Clean and prepare the machine code, remove all non-hex characters (including spaces)
                machine_code = re.sub(r'[^0-9a-fA-F]', '', machine_code)

                # Calculate the offset
                current_offset = int(addr, 16)
                offset = current_offset - text_section_base_addr

                # Prepare IV
                offset_hex = format(offset, 'x')  # Convert offset to hex
                iv_string = (machine_code + offset_hex).ljust(20, '0')[:20]  # Ensure 80 bits

                try:
                    iv = bytes.fromhex(iv_string)  # Ensure it’s valid hex
                except ValueError as e:
                    print(f"Invalid IV format: {iv_string}. Skipping instruction {i}. Error: {e}")
                    continue

                # Generate keystream using Trivium
                keystream = generate_stream(key, iv, N=64)

                # Save instruction info to output.txt
                f_output.write(f"Offset: {offset}\n")  # Offset in decimal format
                f_output.write(f"Machine Code: {machine_code}\n")
                f_output.write(f"IV (hex): {iv_string}\n")
                f_output.write('-' * 40 + '\n')

                # Convert keystream to hexadecimal and save to zhangben.txt
                keystream_hex = hex(int(keystream, 2))[2:].zfill(16)  # Convert binary keystream to hex
                tag = f"{keystream_hex} ({offset}) % "  # Do not add new line after %
                f_tags.write(tag)
                
                counter += 1  # 增加计数器

        print(f"Instructions saved to {output_file}")
        print(f"Tags saved to {tag_file}")
        
    else:
        print("Failed to retrieve instructions.")

# Example usage:
obj_path = r"finance"  # Replace with your .o file path
save_instructions_and_tags(obj_path)