import os
import gdb
import re
import time
from bisect import bisect_right

# 全局变量用于记录 source 阶段的运行时间
source_time = 0.0

# 宏定义变量：修改此处即可改变输出位数（如4, 8, 16, 32, 64等）
TAG_BITS = 64  # 修改此值即可改变输出位数 [[用户需求]]

class CheckPoint:
    def __init__(self, offset, state):
        self.offset = offset
        self.state = state

    def __lt__(self, other):
        return self.offset < other.offset

def generate_stream(initial_state, target_offset, start_offset, delta, from_checkpoint):
    """生成指定偏移量的密钥流"""
    state = initial_state.copy()
    keystream = []
    
    # 计算需要生成的总位数 [[用户需求]]
    total_bits = (delta + 1) * TAG_BITS if from_checkpoint else delta * TAG_BITS

    # 生成密钥流 [[6]]
    for _ in range(total_bits):
        t1 = state[65] ^ (state[90] & state[91]) ^ state[92] ^ state[170]
        t2 = state[161] ^ (state[174] & state[175]) ^ state[176] ^ state[263]
        t3 = state[242] ^ (state[285] & state[286]) ^ state[287] ^ state[68]
        Zi = t1 ^ t2 ^ t3
        keystream.append(str(Zi))  # MSB优先 [[6]]
        # 更新状态 [[6]]
        state = [t1] + state[:92] + [t2] + state[93:176] + [t3] + state[177:287]
    
    # 取最后TAG_BITS位（MSB在前）[[用户需求]]
    return ''.join(keystream)[-TAG_BITS:], state

class Debugger(gdb.Command):
    def __init__(self):
        super(Debugger, self).__init__("stepi_hex", gdb.COMMAND_USER)
        self.text_start = None
        self.compressed_values = {}
        self.saved_return_info = []
        self.compressed_file = os.path.expanduser('/home/tlsend/trivium/add/zhangben2.txt')
        self.checkpoints = []  # 保存点列表
        self.current_state = None  # 当前状态跟踪
        self.last_offset = -1
        self.initialize()

    def initialize(self):
        """初始化阶段：加载保存点和账本数据"""
        start_time = time.time()
        try:
            # 加载保存点
            self.checkpoints = self.load_checkpoints()
            if not self.checkpoints:
                print("错误：未加载到有效保存点")
                return
            else:
                print("保存点加载成功：")
                for cp in self.checkpoints:
                    print(f"Offset: {cp.offset}")
                    print(f"State: {''.join(hex(b)[2:] for b in cp.state[:20])}...")  # 打印部分状态
                    print("=" * 80)
            
            # 加载账本数据
            self.compressed_values = self.load_zhangben_values()
            if not self.compressed_values:
                print("错误：账本加载失败")
                return
            else:
                print("账本加载成功")
        except Exception as e:
            print(f"初始化失败: {e}")
            return
        
        end_time = time.time()
        global source_time
        source_time = end_time - start_time
        print(f"Source阶段运行时间: {source_time:.6f} 秒 [[2]]")

    def load_checkpoints(self):
        """加载state.txt中的保存点"""
        checkpoints = []
        pattern = re.compile(r'Offset:\s*(\d+)\s+State:\s*([0-9a-fA-F]+)')
        try:
            with open('state.txt', 'r') as f:
                content = f.read()
                matches = pattern.findall(content)
                for offset_str, state_str in matches:
                    offset = int(offset_str)
                    # 将十六进制字符串转换为状态数组（每个字符代表4位）
                    state = []
                    for c in state_str:
                        hex_val = int(c, 16)
                        state.append((hex_val >> 3) & 1)
                        state.append((hex_val >> 2) & 1)
                        state.append((hex_val >> 1) & 1)
                        state.append((hex_val >> 0) & 1)
                    checkpoints.append(CheckPoint(offset, state[:288]))  # 取前288位
            # 按偏移量排序
            checkpoints.sort(key=lambda x: x.offset)
            return checkpoints
        except Exception as e:
            print(f"加载保存点失败: {e}")
            return []

    def find_best_checkpoint(self, target_offset):
        """寻找最佳出发点 [[3]][[7]]"""
        if not self.checkpoints:
            return None, 0
        
        # 使用bisect_right进行二分查找
        offsets = [cp.offset for cp in self.checkpoints]
        idx = bisect_right(offsets, target_offset)
        
        candidates = []
        if idx > 0:
            candidates.append(self.checkpoints[idx-1])
        if idx < len(self.checkpoints):
            candidates.append(self.checkpoints[idx])
        
        # 比较候选保存点和当前状态
        best_cp = None
        best_delta = float('inf')
        for cp in candidates:
            delta = target_offset - cp.offset
            if delta >= 0 and delta < best_delta:
                best_cp = cp
                best_delta = delta
        
        # 处理当前状态逻辑
        if self.current_state is not None:
            current_delta = target_offset - self.last_offset
            if current_delta >= 0:
                if current_delta <= 19:
                    return 'current', current_delta
                else:
                    # 比较保存点偏移量和当前偏移量
                    if best_cp and best_cp.offset > self.last_offset:
                        return (best_cp, best_delta) if best_delta < current_delta else ('current', current_delta)
                    else:
                        return ('current', current_delta) if current_delta < best_delta else (best_cp, best_delta)
            else:
                return best_cp, best_delta
        else:
            return best_cp, best_delta

    def print_instruction_info(self, pc):
        """静态验证（带动态验证跳过逻辑）"""
        text_start = self.get_text_start_address()
        if not text_start:
            return
        current_offset = pc - text_start
        
        try:
            # 寻找最佳出发点
            best_source, delta = self.find_best_checkpoint(current_offset)
            from_checkpoint = False
            start_offset = 0
            
            if best_source == 'current':
                initial_state = self.current_state
                from_checkpoint = False
                start_offset = self.last_offset
                print(f"从当前状态出发，delta={delta}")
            elif best_source:
                initial_state = best_source.state
                from_checkpoint = True
                start_offset = best_source.offset
                print(f"从保存点出发，offset={start_offset}，delta={delta}")
            else:
                # 回退到初始保存点（偏移量0）
                initial_state = self.checkpoints[0].state if self.checkpoints else None
                from_checkpoint = True
                start_offset = 0
                print("警告：使用初始保存点")
            
            # 生成密钥流
            keystream_bits, new_state = generate_stream(
                initial_state,
                current_offset,
                start_offset,
                delta,
                from_checkpoint
            )
            
            # 更新当前状态
            self.current_state = new_state
            self.last_offset = current_offset
            
            # 验证逻辑
            machine_code = self.get_instruction_hex(pc)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code)
            machine_code_bits = machine_code_bits.ljust(TAG_BITS, '0')[:TAG_BITS]
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            hex_length = (TAG_BITS + 3) // 4
            current_tag = hex(int(xor_bits, 2))[2:].zfill(hex_length)
            expected_tag = self.compressed_values.get(current_offset, "")
            
            if expected_tag:
                if current_tag == expected_tag:
                    print(f"[静态验证] 偏移量: {current_offset}, Tag: {current_tag}, 验证成功")
                else:
                    print(f"验证失败！中断程序! 偏移量: {current_offset}, 当前Tag: {current_tag}, 预期Tag: {expected_tag}")
                    gdb.execute("quit")
        except Exception as e:
            print(f"生成校验码失败: {e}")

    # 以下是其他关键方法（保持完整实现）
    def get_text_start_address(self):
        """获取.text段基址"""
        if not self.text_start:
            try:
                output = gdb.execute("info files", to_string=True)
                for line in output.splitlines():
                    if ".text" in line:
                        self.text_start = int(line.split()[0], 16)
                        print(f".text段基址: {self.text_start:#x}")
                        break
                if not self.text_start:
                    print("未找到.text段基址")
            except Exception as e:
                print(f"获取基址失败: {e}")
        return self.text_start

    def get_instruction_hex(self, address):
        """获取指令的十六进制表示"""
        try:
            arch = gdb.selected_frame().architecture()
            insn = arch.disassemble(address)[0]
            mem = gdb.selected_inferior().read_memory(address, insn['length']).tobytes()
            return ''.join(f"{b:02x}" for b in mem)
        except gdb.error as e:
            print(f"读取指令失败: {e}")
            return "00" * 16

    def load_zhangben_values(self):
        """加载账本数据"""
        if not os.path.exists(self.compressed_file):
            print(f"账本文件 {self.compressed_file} 不存在")
            return {}
        hex_length = (TAG_BITS + 3) // 4
        pattern = re.compile(rf'([0-9a-fA-F]{{{hex_length}}})\s+\((\d+)\)')
        try:
            values = {}
            with open(self.compressed_file, 'r') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    matches = pattern.findall(line)
                    if not matches:
                        print(f"警告：第{line_num}行格式错误: {line}")
                        continue
                    for match in matches:
                        values[int(match[1])] = match[0].lower()
            return values
        except Exception as e:
            print(f"加载账本失败: {e}")
            return {}

    def is_dynamic_library_call(self, pc):
        """检查是否为动态库调用"""
        try:
            insn = gdb.selected_frame().architecture().disassemble(pc)[0]
            if not insn['asm'].startswith('call'):
                return False
            offset = int.from_bytes(gdb.selected_inferior().read_memory(pc+1, 4), 'little', signed=True)
            target = pc + 5 + offset
            symbol = gdb.execute(f"info symbol {target:#x}", to_string=True)
            return "@plt" in symbol or self.is_in_plt_section(target)
        except Exception as e:
            print(f"检查动态调用失败: {e}")
            return False

    def is_in_plt_section(self, addr):
        """检查地址是否在.plt段中"""
        try:
            plt_info = gdb.execute("maintenance info sections .plt", to_string=True)
            if not plt_info:
                return False
            plt_start = int(plt_info.split()[1], 16)
            plt_end = plt_start + int(plt_info.split()[2], 16)
            return plt_start <= addr < plt_end
        except Exception:
            return False

    def handle_dynamic_call(self, pc):
        """处理动态调用（带状态跟踪）"""
        return_address = pc + 5
        text_start = self.get_text_start_address()
        if not text_start:
            return
        offset = return_address - text_start
        try:
            # 寻找最佳出发点
            best_source, delta = self.find_best_checkpoint(offset)
            from_checkpoint = False
            start_offset = 0
            
            if best_source == 'current':
                initial_state = self.current_state
                from_checkpoint = False
                start_offset = self.last_offset
                print(f"从当前状态出发，delta={delta}")
            elif best_source:
                initial_state = best_source.state
                from_checkpoint = True
                start_offset = best_source.offset
                print(f"从保存点出发，offset={start_offset}，delta={delta}")
            else:
                # 回退到初始保存点
                initial_state = self.checkpoints[0].state if self.checkpoints else None
                from_checkpoint = True
                start_offset = 0
                print("警告：使用初始保存点")
            
            # 生成密钥流
            keystream_bits, new_state = generate_stream(
                initial_state,
                offset,
                start_offset,
                delta,
                from_checkpoint
            )
            
            # 更新状态
            self.current_state = new_state
            self.last_offset = offset
            
            # 验证逻辑
            machine_code = self.get_instruction_hex(return_address)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code).ljust(TAG_BITS, '0')[:TAG_BITS]
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            hex_length = (TAG_BITS + 3) // 4
            current_tag = hex(int(xor_bits, 2))[2:].zfill(hex_length)
            expected_tag = self.compressed_values.get(offset, None)
            
            if not expected_tag:
                print(f"[动态验证] 警告: 偏移量 {offset} 未在账本中找到")
                return
            if current_tag != expected_tag:
                print(f"[动态验证] 调用前Tag不匹配! 预期: {expected_tag}, 实际: {current_tag}")
                gdb.execute("quit")
            else:
                print(f"[动态验证] 调用前Tag验证通过 (偏移量: {offset}, Tag: {current_tag})")
                self.saved_return_info.append((return_address, expected_tag))
        except Exception as e:
            print(f"处理动态调用失败: {e}")

    def handle_dynamic_return(self):
        """处理动态返回（带状态跟踪）"""
        if not self.saved_return_info:
            print("未保存的预期Tag")
            return
        try:
            rbp = int(gdb.execute("info register rbp", to_string=True).split()[1], 16)
            actual_address = int.from_bytes(gdb.selected_inferior().read_memory(rbp + 8, 8), 'little')
        except Exception as e:
            print(f"获取实际返回地址失败: {e}")
            return
        text_start = self.get_text_start_address()
        if not text_start:
            return
        text_end = text_start + 0x1000
        if not (text_start <= actual_address < text_end):
            print(f"[动态验证] 返回地址 {actual_address:#x} 超出.text段范围，跳过验证")
            return
        expected_address, expected_tag = self.saved_return_info.pop()
        if actual_address != expected_address:
            print(f"[动态验证] 返回地址不匹配! 预期: {expected_address:#x}, 实际: {actual_address:#x}")
            gdb.execute("quit")
        try:
            offset = actual_address - text_start
            
            # 寻找最佳出发点
            best_source, delta = self.find_best_checkpoint(offset)
            from_checkpoint = False
            start_offset = 0
            
            if best_source == 'current':
                initial_state = self.current_state
                from_checkpoint = False
                start_offset = self.last_offset
            elif best_source:
                initial_state = best_source.state
                from_checkpoint = True
                start_offset = best_source.offset
            else:
                # 回退到初始保存点
                initial_state = self.checkpoints[0].state if self.checkpoints else None
                from_checkpoint = True
                start_offset = 0
            
            # 生成密钥流
            keystream_bits, new_state = generate_stream(
                initial_state,
                offset,
                start_offset,
                delta,
                from_checkpoint
            )
            
            # 更新状态
            self.current_state = new_state
            self.last_offset = offset
            
            # 验证逻辑
            machine_code = self.get_instruction_hex(actual_address)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code).ljust(TAG_BITS, '0')[:TAG_BITS]
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            hex_length = (TAG_BITS + 3) // 4
            current_tag = hex(int(xor_bits, 2))[2:].zfill(hex_length)
            if current_tag == expected_tag:
                print(f"[动态验证] 返回Tag验证通过 (偏移量: {offset}, Tag: {current_tag})")
            else:
                print(f"[动态验证] 返回Tag不匹配! 预期: {expected_tag}, 实际: {current_tag}")
                gdb.execute("quit")
        except Exception as e:
            print(f"处理动态返回失败: {e}")

    def invoke(self, arg, from_tty):
        """主调试逻辑"""
        start_time = time.time()
        text_start = self.get_text_start_address()
        if not text_start:
            return
        gdb.execute("break main")
        gdb.execute("run")
        while True:
            try:
                pc = gdb.selected_frame().pc()
            except gdb.error:
                print("程序终止")
                break
            insn_hex = self.get_instruction_hex(pc)
            # 处理动态调用
            if insn_hex.lstrip('0').startswith("e8"):
                if self.is_dynamic_library_call(pc):
                    print(f"动态调用检测到: {pc:#x}")
                    self.handle_dynamic_call(pc)
                    gdb.execute("ni")
                    continue
            # 处理动态返回
            elif insn_hex.lstrip('0').startswith("c3") or insn_hex.lstrip('0').startswith("c2"):
                self.handle_dynamic_return()
            # 执行静态验证
            self.print_instruction_info(pc)
            gdb.execute("si")
        print("调试完成")
        end_time = time.time()
        stepi_hex_time = end_time - start_time
        print(f"Stepi_hex阶段运行时间: {stepi_hex_time:.6f} 秒 [[2]]")
        total_time = source_time + stepi_hex_time
        print(f"总运行时间 (Source + Stepi_hex): {total_time:.6f} 秒 [[2]]")

# 注册GDB命令
Debugger()