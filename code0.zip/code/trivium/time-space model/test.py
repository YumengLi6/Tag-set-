import os
import subprocess
import re
import secrets  

# 宏定义变量：修改此处即可改变输出位数（如4, 8, 64等）
TAG_BITS = 16  # 修改此值即可改变输出位数

def get_text_section_info(obj_path):
    """提取.text段指令信息（严格验证） [[7]]"""
    objdump_command = f"objdump -d {obj_path}"
    result = subprocess.run(objdump_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            universal_newlines=True)

    text_section_pattern = re.compile(r"^\s*(\S+):\s+([\da-fA-F\s]+)\s+.*")
    inside_text_section = False
    instructions = []
    text_section_base_addr = None

    for line in result.stdout.splitlines():
        if '.text' in line:
            inside_text_section = True
            continue

        if inside_text_section:
            match = text_section_pattern.match(line)
            if match:
                addr = match.group(1)
                machine_code = match.group(2).replace(" ", "")

                if not text_section_base_addr:
                    text_section_base_addr = addr

                instructions.append((addr, machine_code))
    
    if not instructions or not text_section_base_addr:
        print("No instructions found in .text section")
        return [], None

    print(f"Text section base address: {text_section_base_addr}")
    return instructions, text_section_base_addr

def trivium_initialization(key, iv):
    """严格遵循Trivium规范的初始化（MSB模式） [[4]][[6]]"""
    state = [0] * 288

    # 密钥加载到寄存器A（前93位中的前80位） [[4]]
    for i in range(10):
        for j in range(8):
            bit = (key[i] >> (7 - j)) & 1  # MSB优先分解 [[1]]
            state[i*8 + j] = bit  # 修正索引计算方式

    # IV加载到寄存器B（中间84位中的前80位） [[4]]
    for i in range(10):
        for j in range(8):
            bit = (iv[i] >> (7 - j)) & 1  # MSB优先分解 [[1]]
            state[93 + i*8 + j] = bit  # 修正索引计算方式

    # 寄存器C末尾3位 [[4]]
    state[285:288] = [1, 1, 1]

    # 初始化1152轮 [[6]]
    for _ in range(1152):
        t1 = state[65] ^ (state[90] & state[91]) ^ state[92] ^ state[170]
        t2 = state[161] ^ (state[174] & state[175]) ^ state[176] ^ state[263]
        t3 = state[242] ^ (state[285] & state[286]) ^ state[287] ^ state[68]
        
        # 状态更新（严格遵循寄存器长度） [[6]]
        state = (
            [t1] + state[0:92] + 
            [t2] + state[93:176] + 
            [t3] + state[177:287]
        )
    
    return state

def generate_stream(key, iv, N):
    """生成连续密钥流（动态分配） [[5]]"""
    state = trivium_initialization(key, iv)
    keystream = []

    for _ in range(N):
        # 生成输出位 [[6]]
        t1 = state[65] ^ (state[90] & state[91]) ^ state[92] ^ state[170]
        t2 = state[161] ^ (state[174] & state[175]) ^ state[176] ^ state[263]
        t3 = state[242] ^ (state[285] & state[286]) ^ state[287] ^ state[68]
        keystream_bit = t1 ^ t2 ^ t3
        keystream.append(str(keystream_bit))

        # 状态更新应直接使用当前t值 [[6]]
        new_t1 = t1  # 修正：直接使用t1而非重新计算
        new_t2 = t2
        new_t3 = t3

        state = (
            [new_t1] + state[0:92] + 
            [new_t2] + state[93:176] + 
            [new_t3] + state[177:287]
        )
    
    return ''.join(keystream[:N])

def save_instructions_and_tags(obj_path, output_file="output2.txt", tag_file="zhangben2.txt"):
    instructions, text_section_base_addr = get_text_section_info(obj_path)
    
    # 随机生成80位密钥和IV
    key = secrets.token_bytes(10)
    iv = secrets.token_bytes(10)
    
    with open("key2.txt", "w") as kf:
        kf.write(key.hex())
    with open("iv2.txt", "w") as ivf:
        ivf.write(iv.hex())
    print(f"Using random key: {key.hex()} [[5]]")
    print(f"Using random IV: {iv.hex()} [[5]]")

    if not instructions:
        return

    text_section_base_addr = int(text_section_base_addr, 16)
    max_offset = max(int(addr, 16) - text_section_base_addr for addr, _ in instructions)
    total_keystream_bits = TAG_BITS * (max_offset + 1)  # 修改为使用TAG_BITS

    # 生成完整密钥流 [[5]]
    full_keystream = generate_stream(key, iv, total_keystream_bits)
    keystream_segments = [full_keystream[i:i+TAG_BITS] for i in range(0, len(full_keystream), TAG_BITS)]  # 修改为使用TAG_BITS

    counter = 0

    with open(output_file, "w") as foutput, open(tag_file, "w") as ftag:
        for addr, machine_code in instructions:
            # 严格十六进制清理 [[3]][[10]]
            clean_code = re.sub(r'[^0-9a-fA-F]', '', machine_code)
            
            # 修复奇数长度 [[3]]
            if len(clean_code) % 2 != 0:
                clean_code += '0'
                print(f"Fixed odd-length code at {addr}: {machine_code} -> {clean_code}")
            
            if not clean_code:
                continue

            try:
                # 验证十六进制有效性 [[10]]
                machine_bytes = bytes.fromhex(clean_code)
            except ValueError as e:
                print(f"Skipping invalid machine code at {addr}: {clean_code} ({e})")
                continue

            current_addr = int(addr, 16)
            offset = current_addr - text_section_base_addr
            
            if offset >= len(keystream_segments):
                print(f"Warning: Offset {offset} exceeds available keystream segments")
                continue

            keystream_segment = keystream_segments[offset].ljust(TAG_BITS, '0')[:TAG_BITS]  # 修改为使用TAG_BITS
            
            # 转换机器码（MSB优先补零） [[1]]
            code_bits = ''.join(f"{b:08b}" for b in machine_bytes)
            code_padded = code_bits.ljust(TAG_BITS, '0')[:TAG_BITS]  # 修改为使用TAG_BITS
            
            # 执行异或操作 [[2]]
            xor_result = ''.join(
                str(int(a) ^ int(b)) 
                for a, b in zip(code_padded, keystream_segment)
            )

            # 转换为十六进制标签，并补零确保固定宽度 [[用户需求]]
            hex_length = (TAG_BITS + 3) // 4  # 计算所需的十六进制字符数 [[4]]
            tag_hex = f"{int(xor_result, 2):0{hex_length}x}"  # 补零至固定宽度

            # 写入output1.txt [[用户需求]]
            foutput.write(f"Offset: {offset}\n")
            foutput.write(f"Original Machine Code: {clean_code}\n")
            foutput.write(f"Padded Code Bits: {code_padded}\n")
            foutput.write(f"Keystream Segment: {keystream_segment}\n")
            foutput.write(f"XOR Result: {xor_result}\n")
            foutput.write("-" * 40 + "\n")

            ftag.write(f"{tag_hex} ({offset}) % ")
            counter += 1

    print(f"Processed {counter} instructions with {TAG_BITS}-bit tags")
    print(f"Tags saved to {tag_file}")

# 示例用法
obj_path = r"/home/tlsend/trivium/add/finance"
save_instructions_and_tags(obj_path)