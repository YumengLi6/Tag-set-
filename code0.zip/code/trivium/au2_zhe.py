import os
import gdb
import re
import time

# 全局变量用于记录 source 阶段的运行时间
source_time = 0.0

def trivium_initialization(key, iv):
    state = [0] * 288
    # 正确加载密钥到第一个寄存器（前80位）[[5]]
    for i in range(10):
        key_byte = key[i]
        for j in range(8):
            bit_pos = i * 8 + j
            if bit_pos < 80:
                state[bit_pos] = (key_byte >> (7 - j)) & 1  # 高位在前
    # 正确加载IV到第二个寄存器（93-172位）[[5]]
    for i in range(10):
        iv_byte = iv[i]
        for j in range(8):
            bit_pos = 93 + i * 8 + j
            if bit_pos < 93 + 80:
                state[bit_pos] = (iv_byte >> (7 - j)) & 1  # 高位在前
    # 正确初始化第三个寄存器（173-288位）[[5]]
    for i in range(173, 285):  # 173到284共112位
        state[i] = 0
    state[285] = state[286] = state[287] = 1  # 最后三位设为1
    # 1152次初始化迭代 [[6]]
    for _ in range(1152):
        t1 = state[65] ^ (state[90] & state[91]) ^ state[92] ^ state[170]
        t2 = state[161] ^ (state[174] & state[175]) ^ state[176] ^ state[263]
        t3 = state[242] ^ (state[285] & state[286]) ^ state[287] ^ state[68]
        # 状态更新（高位在前）[[6]]
        state = [t1] + state[:92] + [t2] + state[93:176] + [t3] + state[177:287]
    return state

def generate_stream(initial_state, offset, current_state=None, delta=0):
    state = initial_state.copy() if current_state is None else current_state.copy()
    keystream = []
    if current_state is None:
        total_bits = 64 * (offset + 1)
    else:
        total_bits = delta * 64
    for _ in range(total_bits):
        t1 = state[65] ^ (state[90] & state[91]) ^ state[92] ^ state[170]
        t2 = state[161] ^ (state[174] & state[175]) ^ state[176] ^ state[263]
        t3 = state[242] ^ (state[285] & state[286]) ^ state[287] ^ state[68]
        Zi = t1 ^ t2 ^ t3
        keystream.append(str(Zi))  # MSB优先 [[6]]
        # 更新状态 [[6]]
        state = [t1] + state[:92] + [t2] + state[93:176] + [t3] + state[177:287]
    # 取最后64位（MSB在前）[[6]]
    return ''.join(keystream)[-64:], state

class Debugger(gdb.Command):
    def __init__(self):
        super(Debugger, self).__init__("stepi_hex", gdb.COMMAND_USER)
        self.text_start = None
        self.compressed_values = {}
        self.saved_return_info = []
        self.compressed_file = os.path.expanduser('~/trivium/add/zhangben1.txt')
        self.initial_state = None
        self.current_state = None  # 当前状态跟踪
        self.last_offset = -1
        self.first_instruction = True  # 新增首次执行标志
        self.initialize()

    def initialize(self):
        # 记录 source 阶段开始时间
        start_time = time.time()
        
        try:
            # 加载密钥（10字节）
            with open('key1.txt', 'r') as f:
                key_hex = f.read().strip()
            key = list(bytes.fromhex(key_hex))[:10]
            # 加载IV（10字节）
            with open('iv.txt', 'r') as f:
                iv_hex = f.read().strip()
            iv = list(bytes.fromhex(iv_hex))[:10]
            # 生成初始状态 [[5]]
            self.initial_state = trivium_initialization(key, iv)
            self.current_state = self.initial_state.copy()
            self.last_offset = -1  # 初始化为-1
            print("初始化成功，初始状态已保存")
        except Exception as e:
            print(f"初始化失败: {e}")
            return
        # 加载账本数据
        self.compressed_values = self.load_zhangben_values()
        if not self.compressed_values:
            print("错误：账本加载失败")
        else:
            print("账本加载成功")
        # 记录 source 阶段结束时间并输出
        end_time = time.time()
        global source_time
        source_time = end_time - start_time
        print(f"Source阶段运行时间: {source_time:.6f} 秒 [[2]]")

    def get_text_start_address(self):
        if not self.text_start:
            try:
                output = gdb.execute("info files", to_string=True)
                for line in output.splitlines():
                    if ".text" in line:
                        self.text_start = int(line.split()[0], 16)
                        print(f".text段基址: {self.text_start:#x}")
                        break
                if not self.text_start:
                    print("未找到.text段基址")
            except Exception as e:
                print(f"获取基址失败: {e}")
        return self.text_start

    def get_instruction_hex(self, address):
        try:
            arch = gdb.selected_frame().architecture()
            insn = arch.disassemble(address)[0]
            mem = gdb.selected_inferior().read_memory(address, insn['length']).tobytes()
            return ''.join(f"{b:02x}" for b in mem)
        except gdb.error as e:
            print(f"读取指令失败: {e}")
            return "00" * 16

    def print_instruction_info(self, pc):
        text_start = self.get_text_start_address()
        if not text_start:
            return
        current_offset = pc - text_start

        try:
            # 首次执行强制使用初始状态
            if self.first_instruction:
                print("检测到首条指令，强制使用初始状态")
                self.current_state = self.initial_state.copy()
                keystream_bits, self.current_state = generate_stream(
                    self.initial_state,
                    current_offset,
                    None,
                    0
                )
                self.first_instruction = False
                self.last_offset = current_offset
            else:
                # 处理跳转逻辑
                if current_offset < self.last_offset:
                    print(f"检测到跳转：{self.last_offset} -> {current_offset}")
                    self.current_state = self.initial_state.copy()
                    keystream_bits, self.current_state = generate_stream(
                        self.initial_state,
                        current_offset,
                        None,
                        0
                    )
                else:
                    delta = current_offset - self.last_offset
                    keystream_bits, self.current_state = generate_stream(
                        self.initial_state,
                        current_offset,
                        self.current_state,
                        delta
                    )
            # 处理机器码（MSB优先）[[6]]
            machine_code = self.get_instruction_hex(pc)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code)
            machine_code_bits = machine_code_bits.ljust(64, '0')[:64]
            # 异或运算
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            current_tag = hex(int(xor_bits, 2))[2:].zfill(16)
            # 验证逻辑
            expected_tag = self.compressed_values.get(current_offset, "")
            if expected_tag:
                if current_tag == expected_tag:
                    print(f"[静态验证] 偏移量: {current_offset}, Tag: {current_tag}, 验证成功")
                else:
                    print(f"验证失败！中断程序! 偏移量: {current_offset}, 当前Tag: {current_tag}, 预期Tag: {expected_tag}")
                    gdb.execute("quit")
            self.last_offset = current_offset  # 更新最后偏移量
        except Exception as e:
            print(f"生成校验码失败: {e}")

    def load_zhangben_values(self):
        if not os.path.exists(self.compressed_file):
            print(f"账本文件 {self.compressed_file} 不存在")
            return {}
        try:
            values = {}
            with open(self.compressed_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    matches = re.findall(r'([0-9a-fA-F]{16})\s+\((\d+)\)', line)
                    for match in matches:
                        values[int(match[1])] = match[0].lower()
            return values
        except Exception as e:
            print(f"加载账本失败: {e}")
            return {}

    def is_dynamic_library_call(self, pc):
        try:
            insn = gdb.selected_frame().architecture().disassemble(pc)[0]
            if not insn['asm'].startswith('call'):
                return False
            offset = int.from_bytes(gdb.selected_inferior().read_memory(pc+1, 4), 'little', signed=True)
            target = pc + 5 + offset
            symbol = gdb.execute(f"info symbol {target:#x}", to_string=True)
            return "@plt" in symbol or self.is_in_plt_section(target)
        except Exception as e:
            print(f"检查动态调用失败: {e}")
            return False

    def is_in_plt_section(self, addr):
        try:
            plt_info = gdb.execute("maintenance info sections .plt", to_string=True)
            if not plt_info:
                return False
            plt_start = int(plt_info.split()[1], 16)
            plt_end = plt_start + int(plt_info.split()[2], 16)
            return plt_start <= addr < plt_end
        except Exception:
            return False

    def handle_dynamic_call(self, pc):
        return_address = pc + 5
        text_start = self.get_text_start_address()
        if not text_start:
            return
        offset = return_address - text_start
        expected_tag = self.compressed_values.get(offset, None)
        if not expected_tag:
            print(f"[动态验证] 警告: 偏移量 {offset} 未在账本中找到")
            return
        try:
            keystream_bits, _ = generate_stream(self.initial_state, offset)
            keystream_hex = hex(int(keystream_bits, 2))[2:].zfill(16)
            # 获取机器码并处理
            machine_code = self.get_instruction_hex(return_address)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code)
            machine_code_bits = machine_code_bits.ljust(64, '0')[:64]
            # 异或运算
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            current_tag = hex(int(xor_bits, 2))[2:].zfill(16)
            if current_tag != expected_tag:
                print(f"[动态验证] 调用前Tag不匹配! 预期: {expected_tag}, 实际: {current_tag}")
                gdb.execute("quit")
            else:
                print(f"[动态验证] 调用前Tag验证通过 (偏移量: {offset}, Tag: {current_tag})")
                self.saved_return_info.append((return_address, expected_tag))
        except Exception as e:
            print(f"处理动态调用失败: {e}")

    def handle_dynamic_return(self):
        if not self.saved_return_info:
            print("未保存的预期Tag")
            return
        try:
            rbp = int(gdb.execute("info register rbp", to_string=True).split()[1], 16)
            actual_address = int.from_bytes(gdb.selected_inferior().read_memory(rbp + 8, 8), 'little')
        except Exception as e:
            print(f"获取实际返回地址失败: {e}")
            return
        text_start = self.get_text_start_address()
        if not text_start:
            return
        text_end = text_start + 0x1000
        if not (text_start <= actual_address < text_end):
            print(f"[动态验证] 返回地址 {actual_address:#x} 超出.text段范围，跳过验证")
            return
        expected_address, expected_tag = self.saved_return_info.pop()
        if actual_address != expected_address:
            print(f"[动态验证] 返回地址不匹配! 预期: {expected_address:#x}, 实际: {actual_address:#x}")
            gdb.execute("quit")
        try:
            offset = actual_address - text_start
            keystream_bits, _ = generate_stream(self.initial_state, offset)
            keystream_hex = hex(int(keystream_bits, 2))[2:].zfill(16)
            machine_code = self.get_instruction_hex(actual_address)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code)
            machine_code_bits = machine_code_bits.ljust(64, '0')[:64]
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            current_tag = hex(int(xor_bits, 2))[2:].zfill(16)
            if current_tag == expected_tag:
                print(f"[动态验证] 返回Tag验证通过 (偏移量: {offset}, Tag: {current_tag})")
            else:
                print(f"[动态验证] 返回Tag不匹配! 预期: {expected_tag}, 实际: {current_tag}")
                gdb.execute("quit")
        except Exception as e:
            print(f"处理动态返回失败: {e}")

    def invoke(self, arg, from_tty):
        # 记录 stepi_hex 阶段开始时间
        start_time = time.time()
        
        text_start = self.get_text_start_address()
        if not text_start:
            return
        gdb.execute("break main")
        gdb.execute("run")
        while True:
            try:
                pc = gdb.selected_frame().pc()
            except gdb.error:
                print("程序终止")
                break
            insn_hex = self.get_instruction_hex(pc)
            # 处理动态调用
            if insn_hex.lstrip('0').startswith("e8"):
                if self.is_dynamic_library_call(pc):
                    print(f"动态调用检测到: {pc:#x}")
                    self.handle_dynamic_call(pc)
                    gdb.execute("ni")
                    continue
            # 处理动态返回
            elif insn_hex.lstrip('0').startswith("c3") or insn_hex.lstrip('0').startswith("c2"):
                self.handle_dynamic_return()
            # 执行静态验证
            self.print_instruction_info(pc)
            gdb.execute("si")
        print("调试完成")
        # 记录 stepi_hex 阶段结束时间并输出
        end_time = time.time()
        stepi_hex_time = end_time - start_time
        print(f"Stepi_hex阶段运行时间: {stepi_hex_time:.6f} 秒 [[2]]")
        
        # 输出总运行时间
        total_time = source_time + stepi_hex_time
        print(f"总运行时间 (Source + Stepi_hex): {total_time:.6f} 秒 [[2]]")

# 注册GDB命令
Debugger()