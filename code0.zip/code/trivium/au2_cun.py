import os
import gdb
import re
import time  # 引入时间模块

# 全局状态缓存
state_cache = {}
max_cached_offset = 0

# 全局变量用于记录 source 阶段的运行时间
source_time = 0.0

def trivium_initialization(key, iv):
    """初始化Trivium状态 [[5]]"""
    state = [0] * 288
    # 加载密钥到第一个寄存器（前80位）
    for i in range(10):
        key_byte = key[i]
        for j in range(8):
            bit_pos = i * 8 + j
            if bit_pos < 80:
                state[bit_pos] = (key_byte >> (7 - j)) & 1  # 高位在前
    # 加载IV到第二个寄存器（93-172位）
    for i in range(10):
        iv_byte = iv[i]
        for j in range(8):
            bit_pos = 93 + i * 8 + j
            if bit_pos < 93 + 80:
                state[bit_pos] = (iv_byte >> (7 - j)) & 1  # 高位在前
    # 初始化第三个寄存器（173-288位）
    for i in range(173, 285):  # 173到284共112位
        state[i] = 0
    state[285] = state[286] = state[287] = 1  # 最后三位设为1
    # 1152次初始化迭代 [[6]]
    for _ in range(1152):
        t1 = state[65] ^ (state[90] & state[91]) ^ state[92] ^ state[170]
        t2 = state[161] ^ (state[174] & state[175]) ^ state[176] ^ state[263]
        t3 = state[242] ^ (state[285] & state[286]) ^ state[287] ^ state[68]
        state = [t1] + state[:92] + [t2] + state[93:176] + [t3] + state[177:287]
    return state

def get_state(offset, initial_state):
    """获取指定偏移量的状态"""
    global state_cache, max_cached_offset
    
    if offset < 0:
        return None
        
    if offset in state_cache:
        return state_cache[offset].copy()
    
    current_offset = max_cached_offset
    current_state = state_cache.get(current_offset, initial_state.copy())
    
    while current_offset < offset:
        current_offset += 1
        for _ in range(64):
            t1 = current_state[65] ^ (current_state[90] & current_state[91]) ^ current_state[92] ^ current_state[170]
            t2 = current_state[161] ^ (current_state[174] & current_state[175]) ^ current_state[176] ^ current_state[263]
            t3 = current_state[242] ^ (current_state[285] & current_state[286]) ^ current_state[287] ^ current_state[68]
            current_state = [t1] + current_state[:92] + [t2] + current_state[93:176] + [t3] + current_state[177:287]
        state_cache[current_offset] = current_state.copy()
        max_cached_offset = current_offset
    
    return state_cache[offset].copy()

def generate_stream_optimized(offset, initial_state):
    """优化后的密钥流生成函数"""
    if offset < 0:
        return '0' * 64
        
    previous_state = get_state(offset, initial_state)
    if not previous_state:
        return '0' * 64
        
    current_state = previous_state.copy()
    keystream = []
    for _ in range(64):
        t1 = current_state[65] ^ (current_state[90] & current_state[91]) ^ current_state[92] ^ current_state[170]
        t2 = current_state[161] ^ (current_state[174] & current_state[175]) ^ current_state[176] ^ current_state[263]
        t3 = current_state[242] ^ (current_state[285] & current_state[286]) ^ current_state[287] ^ current_state[68]
        Zi = t1 ^ t2 ^ t3
        keystream.append(str(Zi))
        current_state = [t1] + current_state[:92] + [t2] + current_state[93:176] + [t3] + current_state[177:287]
    
    # 更新缓存
    global state_cache, max_cached_offset
    state_cache[offset+1] = current_state.copy()
    if offset+1 > max_cached_offset:
        max_cached_offset = offset+1
        
    return ''.join(keystream)

class Debugger(gdb.Command):
    def __init__(self):
        super(Debugger, self).__init__("stepi_hex", gdb.COMMAND_USER)
        self.text_start = 0
        self.text_end = 0
        self.compressed_values = {}
        self.saved_return_info = []
        self.compressed_file = os.path.expanduser('~/trivium/add/zhangben1.txt')
        self.initial_state = None
        self.initialize()

    def initialize(self):
        # 记录 source 阶段开始时间
        start_time = time.time()

        try:
            # 加载密钥和IV
            with open('key1.txt', 'r') as f:
                key_hex = f.read().strip()
            key = list(bytes.fromhex(key_hex))[:10]
            
            with open('iv.txt', 'r') as f:
                iv_hex = f.read().strip()
            iv = list(bytes.fromhex(iv_hex))[:10]
            
            self.initial_state = trivium_initialization(key, iv)
            global state_cache, max_cached_offset
            state_cache = {0: self.initial_state.copy()}
            max_cached_offset = 0
            print("初始化成功，状态缓存已创建")
        except Exception as e:
            print(f"初始化失败: {e}")
            return
            
        # 加载账本数据
        self.compressed_values = self.load_zhangben_values()
        if not self.compressed_values:
            print("错误：账本加载失败")
        else:
            print("账本加载成功")

        # 记录 source 阶段结束时间并输出
        end_time = time.time()
        global source_time
        source_time = end_time - start_time
        print(f"Source阶段运行时间: {source_time:.6f} 秒 [[2]]")

    def get_text_segment_range(self):
        """健壮的段地址解析 [[1]][[2]]"""
        if self.text_start and self.text_end:
            return self.text_start, self.text_end
            
        try:
            output = gdb.execute("info files", to_string=True)
            for line in output.splitlines():
                # 匹配不同格式的.text段信息
                match = re.match(r'\s*0x([0-9a-f]+)\s+-\s+0x([0-9a-f]+)\s+is\s+\.text', line)
                if not match:
                    match = re.match(r'\s*0x([0-9a-f]+)\s+0x([0-9a-f]+)\s+\.text', line)
                if match:
                    self.text_start = int(match.group(1), 16)
                    self.text_end = int(match.group(2), 16)
                    print(f"找到.text段: {self.text_start:#x} - {self.text_end:#x}")
                    return self.text_start, self.text_end
        except Exception as e:
            print(f"获取段信息失败: {e}")
        
        print("未找到有效的.text段地址")
        self.text_start = self.text_end = 0
        return 0, 0

    def print_instruction_info(self, pc):
        text_start, text_end = self.get_text_segment_range()
        if pc < text_start or pc >= text_end or text_start == 0:
            print(f"跳过非.text段地址: {pc:#x}")
            return
            
        offset = pc - text_start
        machine_code = self.get_instruction_hex(pc)
        try:
            keystream_bits = generate_stream_optimized(offset, self.initial_state)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code)
            machine_code_bits = machine_code_bits.ljust(64, '0')[:64]
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            current_tag = hex(int(xor_bits, 2))[2:].zfill(16)
            
            expected_tag = self.compressed_values.get(offset, "")
            if expected_tag:
                if current_tag == expected_tag:
                    print(f"[静态验证] 偏移量: {offset}, Tag: {current_tag}, 验证成功")
                else:
                    print(f"验证失败！中断程序! 偏移量: {offset}, 当前Tag: {current_tag}, 预期Tag: {expected_tag}")
                    gdb.execute("quit")
        except Exception as e:
            print(f"生成校验码失败: {e}")

    def invoke(self, arg, from_tty):
        # 记录 stepi_hex 阶段开始时间
        start_time = time.time()

        text_start, text_end = self.get_text_segment_range()
        if text_start == 0:
            print("错误：未找到有效的.text段地址，终止调试")
            return
            
        gdb.execute("break main")
        gdb.execute("run")
        while True:
            try:
                pc = gdb.selected_frame().pc()
            except gdb.error:
                print("程序终止")
                break
                
            # 处理地址有效性
            if pc < text_start or pc >= text_end:
                gdb.execute("si")
                continue
                
            insn_hex = self.get_instruction_hex(pc)
            # 处理动态调用
            if insn_hex.lstrip('0').startswith("e8"):
                if self.is_dynamic_library_call(pc):
                    self.handle_dynamic_call(pc)
                    gdb.execute("ni")
                    continue
            # 处理动态返回
            elif insn_hex.lstrip('0').startswith(("c3", "c2")):
                self.handle_dynamic_return()
                
            # 执行验证
            self.print_instruction_info(pc)
            gdb.execute("si")
        print("调试完成")

        # 记录 stepi_hex 阶段结束时间并输出
        end_time = time.time()
        stepi_hex_time = end_time - start_time
        print(f"Stepi_hex阶段运行时间: {stepi_hex_time:.6f} 秒 [[2]]")
        
        # 输出总运行时间
        total_time = source_time + stepi_hex_time
        print(f"总运行时间 (Source + Stepi_hex): {total_time:.6f} 秒 [[2]]")

    def is_dynamic_library_call(self, pc):
        try:
            insn = gdb.selected_frame().architecture().disassemble(pc)[0]
            if not insn['asm'].startswith('call'):
                return False
            offset = int.from_bytes(gdb.selected_inferior().read_memory(pc+1, 4), 'little', signed=True)
            target = pc + 5 + offset
            symbol = gdb.execute(f"info symbol {target:#x}", to_string=True)
            return "@plt" in symbol or self.is_in_plt_section(target)
        except Exception as e:
            print(f"检查动态调用失败: {e}")
            return False

    def is_in_plt_section(self, addr):
        try:
            plt_info = gdb.execute("maintenance info sections .plt", to_string=True)
            if not plt_info:
                return False
            plt_start = int(plt_info.split()[1], 16)
            plt_end = plt_start + int(plt_info.split()[2], 16)
            return plt_start <= addr < plt_end
        except Exception:
            return False

    def handle_dynamic_call(self, pc):
        return_address = pc + 5
        text_start, text_end = self.get_text_segment_range()
        if not text_start or return_address < text_start or return_address >= text_end:
            print(f"动态调用返回地址超出范围: {return_address:#x}")
            return
        offset = return_address - text_start
        expected_tag = self.compressed_values.get(offset, None)
        if not expected_tag:
            print(f"[动态验证] 警告: 偏移量 {offset} 未在账本中找到")
            return
        try:
            keystream_bits = generate_stream_optimized(offset, self.initial_state)
            keystream_hex = hex(int(keystream_bits, 2))[2:].zfill(16)
            machine_code = self.get_instruction_hex(return_address)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code)
            machine_code_bits = machine_code_bits.ljust(64, '0')[:64]
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            current_tag = hex(int(xor_bits, 2))[2:].zfill(16)
            if current_tag != expected_tag:
                print(f"[动态验证] 调用前Tag不匹配! 预期: {expected_tag}, 实际: {current_tag}")
                gdb.execute("quit")
            else:
                print(f"[动态验证] 调用前Tag验证通过 (偏移量: {offset}, Tag: {current_tag})")
                self.saved_return_info.append((return_address, expected_tag))
        except Exception as e:
            print(f"处理动态调用失败: {e}")

    def handle_dynamic_return(self):
        if not self.saved_return_info:
            print("未保存的预期Tag")
            return
        try:
            rbp = int(gdb.execute("info register rbp", to_string=True).split()[1], 16)
            actual_address = int.from_bytes(gdb.selected_inferior().read_memory(rbp + 8, 8), 'little')
        except Exception as e:
            print(f"获取实际返回地址失败: {e}")
            return
        text_start, text_end = self.get_text_segment_range()
        if not text_start or actual_address < text_start or actual_address >= text_end:
            print(f"[动态验证] 返回地址 {actual_address:#x} 超出.text段范围，跳过验证")
            return
        expected_address, expected_tag = self.saved_return_info.pop()
        if actual_address != expected_address:
            print(f"[动态验证] 返回地址不匹配! 预期: {expected_address:#x}, 实际: {actual_address:#x}")
            gdb.execute("quit")
        try:
            offset = actual_address - text_start
            keystream_bits = generate_stream_optimized(offset, self.initial_state)
            keystream_hex = hex(int(keystream_bits, 2))[2:].zfill(16)
            machine_code = self.get_instruction_hex(actual_address)
            machine_code_bits = ''.join(f'{int(c,16):04b}' for c in machine_code)
            machine_code_bits = machine_code_bits.ljust(64, '0')[:64]
            xor_bits = ''.join(str(int(a)^int(b)) for a,b in zip(machine_code_bits, keystream_bits))
            current_tag = hex(int(xor_bits, 2))[2:].zfill(16)
            if current_tag == expected_tag:
                print(f"[动态验证] 返回Tag验证通过 (偏移量: {offset}, Tag: {current_tag})")
            else:
                print(f"[动态验证] 返回Tag不匹配! 预期: {expected_tag}, 实际: {current_tag}")
                gdb.execute("quit")
        except Exception as e:
            print(f"处理动态返回失败: {e}")

    def load_zhangben_values(self):
        """加载账本数据"""
        if not os.path.exists(self.compressed_file):
            print(f"账本文件 {self.compressed_file} 不存在")
            return {}
        try:
            values = {}
            with open(self.compressed_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    matches = re.findall(r'([0-9a-fA-F]{16})\s+\((\d+)\)', line)
                    for match in matches:
                        values[int(match[1])] = match[0].lower()
            return values
        except Exception as e:
            print(f"加载账本失败: {e}")
            return {}

    def get_instruction_hex(self, address):
        """获取指令机器码"""
        try:
            arch = gdb.selected_frame().architecture()
            insn = arch.disassemble(address)[0]
            mem = gdb.selected_inferior().read_memory(address, insn['length']).tobytes()
            return ''.join(f"{b:02x}" for b in mem)
        except gdb.error as e:
            print(f"读取指令失败: {e}")
            return "00" * 16

# 注册GDB命令
Debugger()